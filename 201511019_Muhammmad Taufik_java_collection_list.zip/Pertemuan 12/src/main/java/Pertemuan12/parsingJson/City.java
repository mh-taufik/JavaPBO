package Pertemuan12.parsingJson;

public class City {
	private String origin, destination;
	
	@Override
	public String toString() {
		return this.destination + " | ";
	}
}
